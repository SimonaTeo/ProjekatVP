create schema sw;
use sw;

create table Kategorija(id int auto_increment,name varchar(50),primary key (id));
create table Dan(id int auto_increment,name varchar(20),primary key (id));
create table Doktor(id int auto_increment,ime varchar(15),prezime varchar(25),godiste varchar(4),primary key(id),KatId int, DanId int, biografija text,foreign key (KatId) references Kategorija(id),foreign key (DanId) references Dan(id));
create table Pregledi(id int auto_increment,doktorId int,ime varchar(15), prezime varchar(20),brojMob varchar(15),primary key(id), foreign key(doktorId) references Doktor(id));


/*
INSERT INTO Doktor (ime, prezime, godiste, KatId, DanId,biografija)
VALUES
    ('Ana', 'Anic', 1969, 2, 3, Dr Ana Anic je rodjena u Beogradu, 1969.godine. Medicinski fakultet je zavrsila sa prosekom 9.5 i upisala specijalizaciju iz ginekolgije. Kontinuirano se edukuje u oblasti izvazivne hirurgije, ali i u svim ostalim oblastima. Bila je predavac na medjunarodnim skupovima iz ginekologije i akuserstva. Govori engleski,nemacki i francuski jezik.),
    ('Petar', 'Petrovic', 1978, 3, 3,Dr Petar Petrovic je rodjen u Novom Sadu 1978. godine gde je zavrsio osnovne studije medicine, sa prosecnom ocenom 9.2. Specijalizaciju je obavljao u Beogradu. Trenutno je stalno zaposlen u Centru za nuklearnu medicinu,Instit za onkologiju, ali takodje radi i kod nas na klinici. U toku svom fakultetskog usavrsavanja, pohadjao je strane kurseve za nuklearnu medicinu u Becu. Clan je Evropskog udrzenja za nuklearnu medicinu.);
*/

/*
INSERT INTO Kategorija (name)
VALUES
    ('Dermatologija'),
    ('Ginekologija'),
    ('Endokrinologija'),
    ('Radiologija'),
    ('Interna medicina'),
    ('Urologija'),
    ('Pedijatrija'),
    ('Oftalmologija');
*/
/*
INSERT INTO Dan (name)
VALUES
    ('Ponedeljak'),
    ('Utorak'),
    ('Sreda'),
    ('Cetvrtak'),
    ('Petak'),
    ('Subota'),
    ('Nedelja');

*/