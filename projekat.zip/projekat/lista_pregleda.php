<?php
    require_once("constants.php");
    require_once("db.php");
    $d = new Database();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Svi zakazani pregledi</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <h1>Zakazani pregledi</h1>
    <table>
		<tr>
			<td>Id pregleda</td>
			<td>Doktor id</td>
			<td>Ime pacijenta</td>
            <td>Prezime pacijenta</td>
			<td>Broj mobilnog</td>
		</tr>
	<?php
    global $d;
	foreach($d->getPreglede() as $pregled) {
    ?>
    <tr>
        <td><?php echo $pregled[COL_PREGLEDI_ID];?></td>
        <td><?php echo $pregled[COL_PREGLEDI_DOKTORID];?></td>
	    <td><?php echo $pregled[COL_PREGLEDI_IME];?></td>
        <td><?php echo $pregled[COL_PREGLEDI_PREZIME];?></td>
        <td><?php echo $pregled[COL_PREGLEDI_BROJMOB];?></td>
    </tr>
    <?php
    }
	?>
	</table>
    
</body>
</html>