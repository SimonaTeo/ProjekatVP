<?php
    require_once("db.php");
    require_once("constants.php");
    $d=new Database();

    function OblastSelect($kat, $default) {
		echo "<select name=$kat>";
        global $d;
		$oblasti = $d->getOblast();
		foreach ($oblasti as $oblast) {
			$selected = $oblast[COL_KATEGORIJA_ID] == $default ? "selected" : "";
			echo "<option value={$oblast[COL_KATEGORIJA_ID]} $selected>{$oblast[COL_KATEGORIJA_NAME]}</option>";
		}
		echo "</select>";
	}

    function DanSelect($kat, $default) {
		echo "<select name=$kat>";
        global $d;
		$dani = $d->getDan();
		foreach ($dani as $dan) {
			$selected = $dan[COL_DAN_ID] == $default ? "selected" : "";
			echo "<option value={$dan[COL_DAN_ID]} $selected>{$dan[COL_DAN_NAME]}</option>";
		}
		echo "</select>";
	}

    $doktori=array();
    if (isset($_GET["pretraga"])) {
        global $d;
		$kat = htmlspecialchars($_GET["kategorija"]);
		$dan = htmlspecialchars($_GET["dan"]);
		$doktori = $d->getDoktori($kat, $dan);

	}

    $kat_init = "";
    $dan_init="";

    function getKategorijaNameById($id) {
        global $d;
        $result = $d->getOblastById($id);
        if (!empty($result)) {
            return $result[0][COL_KATEGORIJA_NAME];
        }
        return '';
    }

    function getDanNameById($id) {
        global $d;
        $result = $d->getDanById($id);
        if (!empty($result)) {
            return $result[0][COL_DAN_NAME];
        }
        return '';
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privatna klinika "ST"</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <h1>Privatna klinika "ST"</h1>
    <h4>Zakaži svoj pregled</h4>

    <form>
        
        Oblast:
        <?php OblastSelect("kategorija", isset($_GET['kategorija']) ? $_GET['kategorija'] : $kat_init);?>
        Dan:
        <?php DanSelect("dan", isset($_GET['dan']) ? $_GET['dan'] : $dan_init);?>
        <input type="submit" value="Pretraži" name="pretraga">
    </form>

    <?php 
    
        if (isset($_GET["pretraga"])) {
            echo "Doktori iz oblasti: " . getKategorijaNameById($kat) . " koji su slobodni ovim danom: ". getDanNameById($dan);
        }
        if(empty($doktori)){
            echo "<br>";
            echo "Nema doktora";
        }
    ?>

    <?php
        foreach ($doktori as $doktor) {
            echo "<p>Ime i prezime:<a href='detalji_doktora.php?id=" . $doktor['id'] . "'>" . $doktor[COL_DOKTOR_IME] . " " . $doktor[COL_DOKTOR_PREZIME] . "</a></p>";
            echo "<p>Godište: " . $doktor[COL_DOKTOR_GODISTE] . "</p>";
            echo "<a href='zakazivanje_termina.php?id=" . $doktor['id'] . "' class='custom-button'>Zakaži termin</a>";
            echo "<hr>";
        }
    ?>
    
</body>
</html>