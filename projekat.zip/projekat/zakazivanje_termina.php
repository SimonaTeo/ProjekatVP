<?php

  require_once("constants.php");
  require_once("db.php");
  $d=new Database();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zakazivanje pregleda</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

  <h1>Zakazi pregled kod izabranog doktora</h1>
  <h3>U formu upisi svoje podatke</h3>
  <h4>Napomena!!Pre nego sto zakazete pregled potrebno je odraditi osnovne nalaze (ukoliko se radi npr o stitnoj zlezdi, onda uradite TSH, FT3, FT4) za ono sto zelite da pregledate.
  Sliku nalaza nam okacite u formi ispod kako bismo imali uvid u to pre pregleda.</h4>
    
  <?php

    if ( isset( $_POST["prosledi"] ) ) {
        kontrolaForme();
    }else {
        prikaziFormu();
    }

    function kontrolaForme(){

      global $d;
      if ( isset( $_FILES["nalaz"] ) and $_FILES["nalaz"]["error"] == UPLOAD_ERR_OK ) {
        if ( $_FILES["nalaz"]["type"] != "image/jpeg" ) {
          echo "<p>Samo jpeg format je prihvatljiv!</p>";
        } elseif ( !move_uploaded_file( $_FILES["nalaz"]["tmp_name"], "images/" . basename( $_FILES["nalaz"]["name"] ) ) ) {
            echo "<p>Postoji problem kod upload-ovanja ove slike</p>" . $_FILES["nalaz"]["error"] ;
        } else {
            setcookie("ime", $_POST["ime"], time() + 60 * 60 * 24 * 365, "/", "", false, true);
            setcookie("prezime", $_POST["prezime"], time() + 60 * 60 * 24 * 365, "/", "", false, true);
            if(isset($_GET["id"])){
              $doktor=$d->getDoktorDetails($_GET["id"]);
              if($doktor){
                if(isset($_POST["prosledi"])){
                  $ime=htmlspecialchars($_POST["ime"]);
                  $prezime=htmlspecialchars($_POST["prezime"]);
                  $brojMob=htmlspecialchars($_POST["brojMob"]);
                  $d->makeRes($_GET["id"],$ime,$prezime,$brojMob);
                }
              }
            }
            echo "<p>Hvala Vam sto ste popunili formu i okacili sliku nalaza.</p>" ;
            echo '<a href="index.php">Vrati se na početnu stranu</a>';
          }
      } else {
          switch( $_FILES["nalaz"]["error"] ) {
            case UPLOAD_ERR_INI_SIZE:
              $poruka = "Slika je veca nego sto je dozvoljeno.";
              break;
            case UPLOAD_ERR_FORM_SIZE:
              $poruka = "Slika je veca nego sto forma dozvoljava.";
              break;
            case UPLOAD_ERR_NO_FILE:
              $poruka = "Niste izabrali nikakvu sliku da okacite.";
              break;
            default:
              $poruka = "Kontaktirajte administratora.";
          }
          echo "<p>Postoji problem kod upload-ovanja ove slike. $poruka</p>";
        }
    }


    function prikaziFormu(){
    ?>
    <form action="<?php echo "?id=".htmlspecialchars($_GET["id"]);?>" method="POST" enctype="multipart/form-data">
            
        <input type="hidden" name="MAX_FILE_SIZE" value="10000000" />

        <label for="ime">Ime:</label>
        <input type="text" name="ime" id="ime" value="<?php echo isset($_COOKIE["ime"]) ? $_COOKIE["ime"] : "";?>" />

        <label for="prezime">Prezime:</label>
        <input type="text" name="prezime" id="prezime" value="<?php echo isset($_COOKIE["prezime"]) ? $_COOKIE["prezime"] : "";?>" />

        <label for="brojMob">Broj telefona:</label>
        <input type="text" name="brojMob" id="brojMob" value="" />

        <label for="nalaz">Slika nalaza</label>
        <input type="file" name="nalaz" id="nalaz" value="" />

        <input type="submit" name="prosledi" value="Sacuvaj podatke i zakazi termin" />

    </form>
    <?php    
    }
    ?>

    <?php
    
  /*
    if (isset($_COOKIE["ime"])) {
        $ime = $_COOKIE["ime"];
        echo "Vrednost kolačića 'ime': $ime";
    } else {
        echo "Kolačić 'ime' nije postavljen.";
    }
    
    if (isset($_COOKIE["prezime"])) {
        $prezime = $_COOKIE["prezime"];
        echo "Vrednost kolačića 'prezime': $prezime";
    } else {
        echo "Kolačić 'prezime' nije postavljen.";
    }*/
    ?>

</body>
</html>