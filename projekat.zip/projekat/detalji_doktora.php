<?php
session_start();
require_once("db.php");
require_once("constants.php");

$d = new Database();

if (isset($_GET["id"])) {
    $doctorId = htmlspecialchars($_GET["id"]);
    $doctorDetails = $d->getDoktorDetails($doctorId);

    if (!empty($doctorDetails)) {
        $doktor = $doctorDetails[0];
    }
}

if (isset($_SESSION['komentari'][$doctorId])) {
    $komentari = $_SESSION['komentari'][$doctorId];
    foreach ($komentari as $komentar) {

        echo "<p>Ime: " . htmlspecialchars($komentar['imePr']) . "</p>";
        echo "<p>Broj pregleda: " . htmlspecialchars($komentar['brPregleda']) . "</p>";
        echo "<p>Komentar: " . htmlspecialchars($komentar['komentar']) . "</p>";
    }
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $errors = array();

    if (empty($_POST["komentar"])) {
        $errors[] = "Vratite se na prethodnu stranicu i unesite komentar.";
    }
    if (empty($_POST["imePr"])) {
        $errors[] = "Vratite se na prethodnu stranicu i unesite ime i prezime.";
    }
    if (empty($_POST["brPregleda"])) {
        $errors[] = "Vratite se na prethodnu stranicu i unesite broj pregleda.";
    }
    if (empty($errors)) {

        $doctorId = htmlspecialchars($_GET["id"]);
        $imePr = htmlspecialchars($_POST["imePr"]);
        $brPregleda = htmlspecialchars($_POST["brPregleda"]);
        $komentar = htmlspecialchars($_POST["komentar"]);

        if (!isset($_SESSION['komentari'][$doctorId])) {
            $_SESSION['komentari'][$doctorId] = array();
        }

        $_SESSION['komentari'][$doctorId][] = array(
            'imePr' => $imePr,
            'brPregleda' => $brPregleda,
            'komentar' => $komentar,
        );
        $porukaZahv = "Hvala što ste upisali komentar!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalji o doktoru</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

    <h1>Biografija</h1>
    <p class="biografija"><?php echo $doktor[COL_DOKTOR_BIOGRAFIJA]; ?></p>
    <h4>Mozete ostaviti komentar o doktoru ukoliko ste bili na pregledu.</h4 >

    <?php
    if (isset($errors) && !empty($errors)) {
        
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>" . htmlspecialchars($error) . "</li>";
        }

        echo "</ul>";
    } elseif (isset($porukaZahv)) {
        echo "<p>" . htmlspecialchars($porukaZahv) . "</p>";
    } else {
        
        ?>
        <form method="post" action="">
        
            Ime i prezime:
            <input class="kom" type="text" id="imePr" name="imePr" required>
            Broj pregleda:
            <input class="kom" type="number" id="brPregleda" name="brPregleda" required><br>
            Komentar:
            <textarea class="kom" id="komentar" name="komentar" rows="5"required></textarea><br>
            <input class="kom" type="submit" value="Pošalji komentar">

        </form>
    <?php
    }
    ?>

    
</body>
</html>