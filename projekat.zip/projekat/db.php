<?php
require_once("constants.php");
class Database{

    private $conn;
    
    public function __construct($configFile = "config.ini")
    {
        if ($config = parse_ini_file($configFile)) {
            $host = $config["host"];
            $database = $config["database"];
            $user = $config["user"];
            $password = $config["password"];
            $this->conn = new PDO("mysql:host=$host;dbname=$database", $user, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
    }

    public function __destruct()
    {
        $this->conn = null;
    }

    public function getOblast()
    {
        try {
            $sql = "SELECT * FROM " . TBL_KATEGORIJA;
            $st = $this->conn->prepare($sql);
            $st->execute();
            return $st->fetchAll();
        } catch (PDOException $e) {
            return array();
        }
    }

    public function getDan()
    {
        try {
            $sql = "SELECT * FROM " . TBL_DAN;
            $st = $this->conn->prepare($sql);
            $st->execute();
            return $st->fetchAll();
        } catch (PDOException $e) {
            return array();
        }
    }

    function getDoktori($kat,$dan){
        try{
            $doktori="SELECT * FROM " . TBL_DOKTOR . " WHERE " . COL_DOKTOR_KATID . " = :KatId AND " . COL_DOKTOR_DANID . " = :DanId";
            $st=$this->conn->prepare($doktori);
            $st->bindValue("KatId", $kat, PDO::PARAM_INT);
            $st->bindValue("DanId", $dan, PDO::PARAM_INT);
            $st->execute();
            return $st->fetchAll();
        }catch(PDOException $e){
            return array();
        }
    }

    function getOblastById($id){
        try{
            $sql = "SELECT * FROM " . TBL_KATEGORIJA . " WHERE " . COL_KATEGORIJA_ID . " = :id";
            $st = $this->conn->prepare($sql);
            $st->bindValue(":id", $id, PDO::PARAM_INT);
            $st->execute();
            return $st->fetchAll();
        } catch(PDOException $e) {
            return array();
        }
    }

    function getDanById($id){
        try{
            $sql = "SELECT * FROM " . TBL_DAN . " WHERE " . COL_DAN_ID . " = :id";
            $st = $this->conn->prepare($sql);
            $st->bindValue(":id", $id, PDO::PARAM_INT);
            $st->execute();
            return $st->fetchAll();
        } catch(PDOException $e) {
            return array();
        }
    }

    function getDoktorDetails($doctorId) {
        try {
            $sql = "SELECT * FROM " . TBL_DOKTOR . " WHERE " . COL_DOKTOR_ID . " = :id";
            $st = $this->conn->prepare($sql);
            $st->bindValue("id", $doctorId, PDO::PARAM_INT);
            $st->execute();
            return $st->fetchAll();
        } catch (PDOException $e) {
            return array();
        }
    }

    function makeRes($doktorId,$ime, $prezime,$brojMob)
    {
        try {
            $sql = "INSERT INTO " . TBL_PREGLEDI . " (".COL_PREGLEDI_DOKTORID.","
                                                          .COL_PREGLEDI_IME.","
                                                          .COL_PREGLEDI_PREZIME.","
                                                          .COL_PREGLEDI_BROJMOB.")"
                          ."VALUES (:doktorId, :ime, :prezime, :brojMob)";
        
            
            $st = $this->conn->prepare($sql);
            $st->bindValue("doktorId", $doktorId, PDO::PARAM_INT);
            $st->bindValue("ime", $ime, PDO::PARAM_STR);
            $st->bindValue("prezime", $prezime, PDO::PARAM_STR);
            $st->bindValue("brojMob",$brojMob,PDO::PARAM_STR);
            return $st->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    function getPreglede()
    {
        try {
            $sql = "SELECT * FROM " . TBL_PREGLEDI;
            $st = $this->conn->prepare($sql);
            $st->execute();
            return $st->fetchAll();
        } catch (PDOException $e) {
            return array();
        }
    }

    function getPregledById($doktorId){
        try{
            $sql = "SELECT * FROM " . TBL_PREGLEDI . " WHERE " . COL_PREGLEDI_DOKTORID . " = :doktorId";
            $st = $this->conn->prepare($sql);
            $st->bindValue(":doktorId", $doktorId, PDO::PARAM_INT);
            $st->execute();
            return $st->fetchAll();
        } catch(PDOException $e) {
            return array();
        }
    }


}
?>