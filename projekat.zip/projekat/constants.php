<?php

    define("TBL_KATEGORIJA","Kategorija");
    define("COL_KATEGORIJA_ID","id");
    define("COL_KATEGORIJA_NAME","name");

    define("TBL_DAN","Dan");
    define("COL_DAN_NAME","name");
    define("COL_DAN_ID","id");

    define("TBL_DOKTOR","Doktor");
    define("COL_DOKTOR_DANID","DanId");
    define("COL_DOKTOR_KATID","KatId");
    define("COL_DOKTOR_IME","ime");
    define("COL_DOKTOR_PREZIME","prezime");
    define("COL_DOKTOR_GODISTE","godiste");
    define("COL_DOKTOR_BIOGRAFIJA","biografija");
    define("COL_DOKTOR_ID","id");

    define("TBL_PREGLEDI","Pregledi");
    define("COL_PREGLEDI_ID","id");
    define("COL_PREGLEDI_DOKTORID","doktorId");
    define("COL_PREGLEDI_IME","ime");
    define("COL_PREGLEDI_PREZIME","prezime");
    define("COL_PREGLEDI_BROJMOB","brojMob");
